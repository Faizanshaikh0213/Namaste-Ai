import { useState } from 'react';

function App() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');

  const sendMessage = async () => {
    if (!input.trim()) return;
    const userMessage = { role: 'user', content: input };
    const newMessages = [...messages, userMessage];
    setMessages(newMessages);
    setInput('');

    const res = await fetch('https://openrouter.ai/api/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer YOUR_OPENROUTER_API_KEY',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: 'openchat/openchat-3.5-0106',
        messages: newMessages,
      }),
    });

    const data = await res.json();
    const reply = data.choices?.[0]?.message?.content || "No reply";
    setMessages([...newMessages, { role: 'assistant', content: reply }]);
  };

  return (
    <div style={{ padding: 20, fontFamily: 'sans-serif' }}>
      <h1>Namaste! Me kaise madad kar sakta hoon?</h1>
      <div style={{ margin: '20px 0' }}>
        {messages.map((msg, i) => (
          <div key={i}><b>{msg.role}:</b> {msg.content}</div>
        ))}
      </div>
      <input value={input} onChange={e => setInput(e.target.value)} style={{ width: '80%' }} />
      <button onClick={sendMessage}>Send</button>
    </div>
  );
}

export default App;